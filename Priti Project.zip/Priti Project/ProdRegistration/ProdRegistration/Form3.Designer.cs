﻿namespace ProdRegistration
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxSearchProduct = new System.Windows.Forms.ComboBox();
            this.productRegBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.productRegDBDataSet = new ProdRegistration.ProductRegDBDataSet();
            this.productRegTableAdapter = new ProdRegistration.ProductRegDBDataSetTableAdapters.ProductRegTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.productRegBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productRegDBDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(139, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "Search";
            // 
            // comboBoxSearchProduct
            // 
            this.comboBoxSearchProduct.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.productRegBindingSource, "ProdName", true));
            this.comboBoxSearchProduct.FormattingEnabled = true;
            this.comboBoxSearchProduct.IntegralHeight = false;
            this.comboBoxSearchProduct.ItemHeight = 13;
            this.comboBoxSearchProduct.Location = new System.Drawing.Point(265, 89);
            this.comboBoxSearchProduct.Name = "comboBoxSearchProduct";
            this.comboBoxSearchProduct.Size = new System.Drawing.Size(130, 21);
            this.comboBoxSearchProduct.TabIndex = 1;
            this.comboBoxSearchProduct.SelectedIndexChanged += new System.EventHandler(this.comboBoxSearchProduct_SelectedIndexChanged);
            // 
            // productRegBindingSource
            // 
            this.productRegBindingSource.DataMember = "ProductReg";
            this.productRegBindingSource.DataSource = this.productRegDBDataSet;
            // 
            // productRegDBDataSet
            // 
            this.productRegDBDataSet.DataSetName = "ProductRegDBDataSet";
            this.productRegDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // productRegTableAdapter
            // 
            this.productRegTableAdapter.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(153, 165);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(139, 29);
            this.button1.TabIndex = 2;
            this.button1.Text = "Export To Excel";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(841, 441);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.comboBoxSearchProduct);
            this.Controls.Add(this.label1);
            this.Name = "Form3";
            this.Text = "Search Product";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.productRegBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productRegDBDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxSearchProduct;
        private ProductRegDBDataSet productRegDBDataSet;
        private System.Windows.Forms.BindingSource productRegBindingSource;
        private ProductRegDBDataSetTableAdapters.ProductRegTableAdapter productRegTableAdapter;
        private System.Windows.Forms.Button button1;
    }
}