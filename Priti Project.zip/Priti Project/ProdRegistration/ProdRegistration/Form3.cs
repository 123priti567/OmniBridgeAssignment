﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
//using Excel = Microsoft; 

namespace ProdRegistration
{
    public partial class Form3 : Form
    {
        string ConnectionString = @"Data Source=SYDQASQL2;Initial Catalog=ProductRegDB;Integrated Security=True";

        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'productRegDBDataSet.ProductReg' table. You can move, or remove it, as needed.
           // this.productRegTableAdapter.Fill(this.productRegDBDataSet.ProductReg);

            using (SqlConnection sqlCon = new SqlConnection(ConnectionString))
            {

                try
                {

                    string query = "select ProdName from dbo.ProductReg";
                    SqlDataAdapter da = new SqlDataAdapter(query, sqlCon);
                    sqlCon.Open();
                    DataSet ds = new DataSet();
                    da.Fill(ds, "Product");
                    comboBoxSearchProduct.DisplayMember = "ProdName";
                    comboBoxSearchProduct.ValueMember = "ProdName";
                    comboBoxSearchProduct.DataSource = ds.Tables["Product"];
                }
                catch
                {
                    MessageBox.Show("Error ");
                }
            }

        }

       

      

        private void comboBoxSearchProduct_SelectedIndexChanged(object sender, EventArgs e)
        {

         }

        private void button1_Click(object sender, EventArgs e)
        {

            //SqlConnection sqlCon = new SqlConnection(ConnectionString);
            

               
            //SqlCommand command = new SqlCommand();
            //command.CommandText = "select * from ProductReg where ProdName="+comboBoxSearchProduct.Text.Trim();
            //using (SqlDataAdapter dataAdapter = new SqlDataAdapter(command.CommandText, sqlCon))
            //{
            //    DataTable t = new DataTable();
            //    dataAdapter.Fill(t);
            //}

            //Workbook book = new Workbook();
            //Worksheet sheet = book.Worksheets[0];
            //sheet.InsertDataTable(t, true, 1, 1);
            //book.SaveToFile("ToExcel.xls");
           

        }
    }
}
