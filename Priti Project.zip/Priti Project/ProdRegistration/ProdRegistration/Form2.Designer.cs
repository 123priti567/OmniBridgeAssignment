﻿namespace ProdRegistration
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridViewProductDetails = new System.Windows.Forms.DataGridView();
            this.productRegDBDataSet = new ProdRegistration.ProductRegDBDataSet();
            this.productRegBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.productRegTableAdapter = new ProdRegistration.ProductRegDBDataSetTableAdapters.ProductRegTableAdapter();
            this.prodNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodQuantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodGSTDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodPurchaseDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prodExpiryDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coloursDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProductDetails)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productRegDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productRegBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewProductDetails
            // 
            this.dataGridViewProductDetails.AllowUserToAddRows = false;
            this.dataGridViewProductDetails.AllowUserToDeleteRows = false;
            this.dataGridViewProductDetails.AllowUserToOrderColumns = true;
            this.dataGridViewProductDetails.AutoGenerateColumns = false;
            this.dataGridViewProductDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewProductDetails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.prodNameDataGridViewTextBoxColumn,
            this.prodPriceDataGridViewTextBoxColumn,
            this.prodQuantityDataGridViewTextBoxColumn,
            this.prodGSTDataGridViewTextBoxColumn,
            this.prodPurchaseDateDataGridViewTextBoxColumn,
            this.prodExpiryDateDataGridViewTextBoxColumn,
            this.coloursDataGridViewTextBoxColumn});
            this.dataGridViewProductDetails.DataSource = this.productRegBindingSource;
            this.dataGridViewProductDetails.Location = new System.Drawing.Point(128, 57);
            this.dataGridViewProductDetails.Name = "dataGridViewProductDetails";
            this.dataGridViewProductDetails.Size = new System.Drawing.Size(748, 427);
            this.dataGridViewProductDetails.TabIndex = 0;
            this.dataGridViewProductDetails.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewProductDetails_CellContentClick);
            // 
            // productRegDBDataSet
            // 
            this.productRegDBDataSet.DataSetName = "ProductRegDBDataSet";
            this.productRegDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // productRegBindingSource
            // 
            this.productRegBindingSource.DataMember = "ProductReg";
            this.productRegBindingSource.DataSource = this.productRegDBDataSet;
            // 
            // productRegTableAdapter
            // 
            this.productRegTableAdapter.ClearBeforeFill = true;
            // 
            // prodNameDataGridViewTextBoxColumn
            // 
            this.prodNameDataGridViewTextBoxColumn.DataPropertyName = "ProdName";
            this.prodNameDataGridViewTextBoxColumn.HeaderText = "ProdName";
            this.prodNameDataGridViewTextBoxColumn.Name = "prodNameDataGridViewTextBoxColumn";
            // 
            // prodPriceDataGridViewTextBoxColumn
            // 
            this.prodPriceDataGridViewTextBoxColumn.DataPropertyName = "ProdPrice";
            this.prodPriceDataGridViewTextBoxColumn.HeaderText = "ProdPrice";
            this.prodPriceDataGridViewTextBoxColumn.Name = "prodPriceDataGridViewTextBoxColumn";
            // 
            // prodQuantityDataGridViewTextBoxColumn
            // 
            this.prodQuantityDataGridViewTextBoxColumn.DataPropertyName = "ProdQuantity";
            this.prodQuantityDataGridViewTextBoxColumn.HeaderText = "ProdQuantity";
            this.prodQuantityDataGridViewTextBoxColumn.Name = "prodQuantityDataGridViewTextBoxColumn";
            // 
            // prodGSTDataGridViewTextBoxColumn
            // 
            this.prodGSTDataGridViewTextBoxColumn.DataPropertyName = "ProdGST";
            this.prodGSTDataGridViewTextBoxColumn.HeaderText = "ProdGST";
            this.prodGSTDataGridViewTextBoxColumn.Name = "prodGSTDataGridViewTextBoxColumn";
            // 
            // prodPurchaseDateDataGridViewTextBoxColumn
            // 
            this.prodPurchaseDateDataGridViewTextBoxColumn.DataPropertyName = "ProdPurchaseDate";
            this.prodPurchaseDateDataGridViewTextBoxColumn.HeaderText = "ProdPurchaseDate";
            this.prodPurchaseDateDataGridViewTextBoxColumn.Name = "prodPurchaseDateDataGridViewTextBoxColumn";
            // 
            // prodExpiryDateDataGridViewTextBoxColumn
            // 
            this.prodExpiryDateDataGridViewTextBoxColumn.DataPropertyName = "ProdExpiryDate";
            this.prodExpiryDateDataGridViewTextBoxColumn.HeaderText = "ProdExpiryDate";
            this.prodExpiryDateDataGridViewTextBoxColumn.Name = "prodExpiryDateDataGridViewTextBoxColumn";
            // 
            // coloursDataGridViewTextBoxColumn
            // 
            this.coloursDataGridViewTextBoxColumn.DataPropertyName = "Colours";
            this.coloursDataGridViewTextBoxColumn.HeaderText = "Colours";
            this.coloursDataGridViewTextBoxColumn.Name = "coloursDataGridViewTextBoxColumn";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1011, 566);
            this.Controls.Add(this.dataGridViewProductDetails);
            this.Name = "Form2";
            this.Text = "Product Details";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProductDetails)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productRegDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productRegBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewProductDetails;
        private ProductRegDBDataSet productRegDBDataSet;
        private System.Windows.Forms.BindingSource productRegBindingSource;
        private ProductRegDBDataSetTableAdapters.ProductRegTableAdapter productRegTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodQuantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodGSTDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodPurchaseDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prodExpiryDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn coloursDataGridViewTextBoxColumn;
    }
}