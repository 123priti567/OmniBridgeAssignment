﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProdRegistration
{
    public partial class Form1 : Form
    {
        string ConnectionString = @"Data Source=SYDQASQL2;Initial Catalog=ProductRegDB;Integrated Security=True";

        public Form1()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string gst = "";
            Boolean isChecked=radioButtonGST1.Checked;
            if(isChecked)
            {
                gst = radioButtonGST1.Text.Trim();
            }
            else
            {
                gst = radioButtonGST2.Text.Trim();
            }
           
            using (SqlConnection sqlCon = new SqlConnection(ConnectionString))
            {
                sqlCon.Open();
                //code for calling stored proc
                try
                {
                    SqlCommand sqlcmd = new SqlCommand("ProductAdd", sqlCon);
                    sqlcmd.CommandType = CommandType.StoredProcedure;
                    sqlcmd.Parameters.AddWithValue("@ProdName", txtName.Text.Trim());
                    sqlcmd.Parameters.AddWithValue("@ProdPrice", txtPrice.Text.Trim());
                    sqlcmd.Parameters.AddWithValue("@ProdQuantity", txtQuantity.Text.Trim());
                    sqlcmd.Parameters.AddWithValue("@ProdGST", gst);
                    sqlcmd.Parameters.AddWithValue("@ProdPurchaseDate", dateTimePurchase.Value);
                    sqlcmd.Parameters.AddWithValue("@ProdExpiryDate", dateTimeExpiry.Value);
                    sqlcmd.Parameters.AddWithValue("@Colours", comboBoxColours.Text.Trim());

                    sqlcmd.ExecuteNonQuery();
                   
                }
                catch(Exception exc )
                {
                    MessageBox.Show(exc.ToString());
                }
                MessageBox.Show("Product Detail entered successfully !!");

                clear();
            }           
        }


        void clear()
        {
            txtName.Text = txtPrice.Text = txtQuantity.Text = "";
            radioButtonGST1.Checked = false;
            radioButtonGST2.Checked = false;
            dateTimePurchase.ResetText();
            dateTimeExpiry.ResetText();
            comboBoxColours.Text = "";

        }

        private void GST_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
