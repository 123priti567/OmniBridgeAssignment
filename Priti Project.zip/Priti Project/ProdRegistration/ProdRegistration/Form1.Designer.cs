﻿namespace ProdRegistration
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.lblPrice = new System.Windows.Forms.Label();
            this.txtQuantity = new System.Windows.Forms.TextBox();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.lblPruchaseDate = new System.Windows.Forms.Label();
            this.dateTimePurchase = new System.Windows.Forms.DateTimePicker();
            this.dateTimeExpiry = new System.Windows.Forms.DateTimePicker();
            this.lblExpiryDate = new System.Windows.Forms.Label();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.comboBoxColours = new System.Windows.Forms.ComboBox();
            this.lblColours = new System.Windows.Forms.Label();
            this.radioButtonGST1 = new System.Windows.Forms.RadioButton();
            this.radioButtonGST2 = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(113, 72);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(69, 27);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Name";
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(299, 73);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(197, 27);
            this.txtName.TabIndex = 1;
            // 
            // txtPrice
            // 
            this.txtPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrice.Location = new System.Drawing.Point(299, 135);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(197, 27);
            this.txtPrice.TabIndex = 3;
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice.Location = new System.Drawing.Point(113, 134);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(62, 27);
            this.lblPrice.TabIndex = 2;
            this.lblPrice.Text = "Price";
            // 
            // txtQuantity
            // 
            this.txtQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQuantity.Location = new System.Drawing.Point(299, 197);
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.Size = new System.Drawing.Size(197, 27);
            this.txtQuantity.TabIndex = 5;
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantity.Location = new System.Drawing.Point(113, 196);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(96, 27);
            this.lblQuantity.TabIndex = 4;
            this.lblQuantity.Text = "Quantity";
            // 
            // lblPruchaseDate
            // 
            this.lblPruchaseDate.AutoSize = true;
            this.lblPruchaseDate.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPruchaseDate.Location = new System.Drawing.Point(113, 311);
            this.lblPruchaseDate.Name = "lblPruchaseDate";
            this.lblPruchaseDate.Size = new System.Drawing.Size(152, 27);
            this.lblPruchaseDate.TabIndex = 7;
            this.lblPruchaseDate.Text = "Purchase Date";
            // 
            // dateTimePurchase
            // 
            this.dateTimePurchase.Location = new System.Drawing.Point(299, 311);
            this.dateTimePurchase.Name = "dateTimePurchase";
            this.dateTimePurchase.Size = new System.Drawing.Size(200, 20);
            this.dateTimePurchase.TabIndex = 8;
            // 
            // dateTimeExpiry
            // 
            this.dateTimeExpiry.Location = new System.Drawing.Point(299, 377);
            this.dateTimeExpiry.Name = "dateTimeExpiry";
            this.dateTimeExpiry.Size = new System.Drawing.Size(200, 20);
            this.dateTimeExpiry.TabIndex = 10;
            this.dateTimeExpiry.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // lblExpiryDate
            // 
            this.lblExpiryDate.AutoSize = true;
            this.lblExpiryDate.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExpiryDate.Location = new System.Drawing.Point(113, 377);
            this.lblExpiryDate.Name = "lblExpiryDate";
            this.lblExpiryDate.Size = new System.Drawing.Size(129, 27);
            this.lblExpiryDate.TabIndex = 9;
            this.lblExpiryDate.Text = "Expiry Date";
            this.lblExpiryDate.Click += new System.EventHandler(this.label5_Click);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.Location = new System.Drawing.Point(231, 528);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(144, 49);
            this.btnSubmit.TabIndex = 11;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // comboBoxColours
            // 
            this.comboBoxColours.FormattingEnabled = true;
            this.comboBoxColours.Items.AddRange(new object[] {
            "Red",
            "Blue",
            "Green",
            "Yellow",
            "Orange",
            "Pink",
            "Silver",
            "Grey",
            "Black"});
            this.comboBoxColours.Location = new System.Drawing.Point(299, 452);
            this.comboBoxColours.Name = "comboBoxColours";
            this.comboBoxColours.Size = new System.Drawing.Size(121, 21);
            this.comboBoxColours.TabIndex = 12;
            // 
            // lblColours
            // 
            this.lblColours.AutoSize = true;
            this.lblColours.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColours.Location = new System.Drawing.Point(115, 446);
            this.lblColours.Name = "lblColours";
            this.lblColours.Size = new System.Drawing.Size(87, 27);
            this.lblColours.TabIndex = 13;
            this.lblColours.Text = "Colours";
            // 
            // radioButtonGST1
            // 
            this.radioButtonGST1.AutoSize = true;
            this.radioButtonGST1.Location = new System.Drawing.Point(299, 245);
            this.radioButtonGST1.Name = "radioButtonGST1";
            this.radioButtonGST1.Size = new System.Drawing.Size(48, 19);
            this.radioButtonGST1.TabIndex = 14;
            this.radioButtonGST1.TabStop = true;
            this.radioButtonGST1.Text = "Yes";
            this.radioButtonGST1.UseVisualStyleBackColor = true;
            // 
            // radioButtonGST2
            // 
            this.radioButtonGST2.AutoSize = true;
            this.radioButtonGST2.Location = new System.Drawing.Point(385, 245);
            this.radioButtonGST2.Name = "radioButtonGST2";
            this.radioButtonGST2.Size = new System.Drawing.Size(44, 19);
            this.radioButtonGST2.TabIndex = 15;
            this.radioButtonGST2.TabStop = true;
            this.radioButtonGST2.Text = "No";
            this.radioButtonGST2.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(113, 245);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 27);
            this.label1.TabIndex = 16;
            this.label1.Text = "GST";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(680, 658);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.radioButtonGST2);
            this.Controls.Add(this.radioButtonGST1);
            this.Controls.Add(this.lblColours);
            this.Controls.Add(this.comboBoxColours);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.dateTimeExpiry);
            this.Controls.Add(this.lblExpiryDate);
            this.Controls.Add(this.dateTimePurchase);
            this.Controls.Add(this.lblPruchaseDate);
            this.Controls.Add(this.txtQuantity);
            this.Controls.Add(this.lblQuantity);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblName);
            this.Name = "Form1";
            this.Text = "Product Registration";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.TextBox txtQuantity;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.Label lblPruchaseDate;
        private System.Windows.Forms.DateTimePicker dateTimePurchase;
        private System.Windows.Forms.DateTimePicker dateTimeExpiry;
        private System.Windows.Forms.Label lblExpiryDate;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.ComboBox comboBoxColours;
        private System.Windows.Forms.Label lblColours;
        private System.Windows.Forms.RadioButton radioButtonGST1;
        private System.Windows.Forms.RadioButton radioButtonGST2;
        private System.Windows.Forms.Label label1;
    }
}

