﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;
namespace ProdRegistration
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'productRegDBDataSet.ProductReg' table. You can move, or remove it, as needed.
            this.productRegTableAdapter.Fill(this.productRegDBDataSet.ProductReg);
           // string ConnectionString = @"Data Source=SYDQASQL2;Initial Catalog=ProductRegDB;Integrated Security=True";

        }

        private void dataGridViewProductDetails_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
